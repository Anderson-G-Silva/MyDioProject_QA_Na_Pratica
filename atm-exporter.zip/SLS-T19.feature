Feature: Cliente tem cadastro na rede social e está conectado a ela no momento, mas não quer continuar com o acesso 
    @TestCaseKey=SLS-T19
    Scenario: Cliente tem cadastro na rede social e está conectado a ela no momento, mas não quer continuar com o acesso 
        
        # language: pt
        Given que o cliente esteja na tela de interface de login da rede social
        And tenha cadastro no sistema da rede social
        And está conectado a conta da rede social no momento
        When clicar no botão cancelar
        Then o cliente  é direcionado para a tela anterior de acesso de login, criação de usuário e recuperação de senha