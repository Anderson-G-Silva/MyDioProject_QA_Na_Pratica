Feature: Cliente sem cadastro tenta fazer login
    @TestCaseKey=SLS-T1
    Scenario: Cliente sem cadastro tenta fazer login
        
        # language: pt
        Given que o cliente esteja na tela de login na URL https://www.saucedemo.com/
        And digita no campo username Maria_Souza
        And digita no campo password a senha Ma@Sa$1599
        When clicar no botão login
        Then o cliente recebe uma mensagem na tela informando que a conta não existe 
        And uma mensagem orientando a criar uma nova conta