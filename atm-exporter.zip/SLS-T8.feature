Feature: Cliente preenche dados para criação de nova conta e informa CPF já cadastrado na base de clientes
    @TestCaseKey=SLS-T8
    Scenario: Cliente preenche dados para criação de nova conta e informa CPF já cadastrado na base de clientes
        
        # Language: pt
        Given que o cliente esteja na tela de criação de nova conta
        And digita no campo username Maria_Maria
        And digita no campo nome completo Maria de Souza
        And digita no campo data de nascimento 01/01/2000
        But digita no campo CPF 12345678909
        And digita no campo E-mail mariasouza@hotmail.com
        And digita no campo password Ma@Sa$1599
        And digita no campo confirmar password Ma@Sa$1599
        When clicar no botão criar conta
        Then o cliente recebe uma mensagem na tela informando que existe uma conta ativa com o mesmo CPF
        And retorna para a tela inicial de login.