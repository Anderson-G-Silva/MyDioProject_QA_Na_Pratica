Feature: Cliente preenche dados para criação de nova conta e informa senha que não atende as regras de criação de senha
    @TestCaseKey=SLS-T10
    Scenario: Cliente preenche dados para criação de nova conta e informa senha que não atende as regras de criação de senha
        
        # Language: pt
        Given que o cliente esteja na tela de criação de nova conta
        And digita no campo username Maria_Souza
        And digita no campo nome completo Maria de Souza
        And digita no campo data de nascimento 01/01/2000
        And digita no campo CPF 12345678909
        And digita no campo E-mail mariasouza@gmail.com
        But digita no campo password MaSa1599
        And digita no campo confirmar password MaSa1599
        When clicar no botão criar conta
        Then o cliente recebe uma mensagem na tela informando que a senha não atende aos requisitos solicitados para criação de senha.