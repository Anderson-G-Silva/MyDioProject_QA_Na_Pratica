Feature: Cliente clica no botão novo endereço ou no link alterar e é direcionado para a tela e preenche dados para criação de novo endereço ou alteração com CEP inválido
    @TestCaseKey=SLS-T20
    Scenario Outline: Cliente clica no botão novo endereço ou no link alterar e é direcionado para a tela e preenche dados para criação de novo endereço ou alteração com CEP inválido
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de endereços
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de endereço
        And digita no campo nome do endereço Casa
        And digita no campo CEP 03000000
        When finalizar consulta da API
        Then o cliente recebe uma mensagem na tela informando que o CEP não existe
        Examples: | ação | | botão novo endereço | | link alterar de um endereço cadastrado |