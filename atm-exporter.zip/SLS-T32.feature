Feature: Cliente clica no link excluir é direcionado para a tela de exclusão de meios de pagamento e conclui o processo
    @TestCaseKey=SLS-T32
    Scenario: Cliente clica no link excluir é direcionado para a tela de exclusão de meios de pagamento e conclui o processo
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de meios de pagamento
        And clica no link excluir de um meio de pagamento cadastrado
        And é direcionado para a tela de excusão de meios de pagamento
        And seleciona o cartão nomeado Mastercard-Crédito
        When clicar no botão confirmar exclusão
        Then o cliente recebe uma mensagem na tela informando que a exclusão foi concluída com sucesso
        And retorna a tela inicial de meios de pagamento