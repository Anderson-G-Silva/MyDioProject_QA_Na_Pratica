Feature: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita nova senha que não atende as regras de criação de senha
    @TestCaseKey=SLS-T12
    Scenario: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita nova senha que não atende as regras de criação de senha
        
        # language: pt
        Given que o cliente esteja na tela de recuperação de senha
        And digita o e-mail cadastrado mariasouza@gmail.com
        And recebe e-mail com código para recuperação de senha 123456
        And digita na tela de recuperação de senha o codigo 123456
        But digita no campo password MaSa15
        And digita no campo confirmar password MaSa15
        When clicar no botão salvar senha
        Then o cliente recebe uma mensagem na tela informando que a nova senha não atende aos requisitos solicitados para criação de senha