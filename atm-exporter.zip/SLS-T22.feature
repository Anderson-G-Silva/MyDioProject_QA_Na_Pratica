Feature: Cliente clica no botão novo endereço ou no link alterar é direcionado para a tela e preenche dados para criação de novo endereço ou alteração com CEP válido, mas digita letras ou caracteres especiais no campo número
    @TestCaseKey=SLS-T22
    Scenario Outline: Cliente clica no botão novo endereço ou no link alterar é direcionado para a tela e preenche dados para criação de novo endereço ou alteração com CEP válido, mas digita letras ou caracteres especiais no campo número
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de endereços
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de endereço
        And digita no campo nome do endereço Casa
        And digita no campo CEP 03104000
        But digita no campo número 905A$
        When clicar no botão salvar endereço
        Then o cliente recebe uma mensagem na tela informando que no campo destacado em vermelho só são permitidos números de 0 a 9
        Examples: | ação | | botão novo endereço | | link alterar de um endereço cadastrado |