Feature: Cliente clica no botão novo endereço ou no link alterar e é direcionado para a tela e preenche dados para criação de novo endereço ou alteração e digita no campo CEP caracteres alfabéticos ou caracteres especiais
    @TestCaseKey=SLS-T21
    Scenario Outline: Cliente clica no botão novo endereço ou no link alterar e é direcionado para a tela e preenche dados para criação de novo endereço ou alteração e digita no campo CEP caracteres alfabéticos ou caracteres especiais
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de endereços
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de endereço
        And digita no campo nome do endereço Casa
        And digita no campo CEP A3$00000
        When tenta avançar na pesquisa do CEP
        Then o cliente recebe uma mensagem na tela informando que o campo CEP só aceita caracteres numéricos de 0 a 9
        Examples: | ação | | botão novo endereço | | link alterar de um endereço cadastrado |