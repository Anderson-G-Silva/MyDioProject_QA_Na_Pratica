Feature: Cliente tem cadastro e tenta fazer login utilizando uma rede social
    @TestCaseKey=SLS-T6
    Scenario: Cliente tem cadastro e tenta fazer login utilizando uma rede social
        
        # language: pt
        Given que o cliente esteja na tela de login na URL https://www.saucedemo.com/
        And  tenha cadastro no sistema de uma das redes sociais
        When clicar no logotipo da rede social Facebook
        Then o cliente  é direcionado para a tela de acesso da rede social Facebook