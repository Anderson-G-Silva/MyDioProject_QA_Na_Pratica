Feature: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita no campo da tela de recuperação de senha o código incorreto
    @TestCaseKey=SLS-T14
    Scenario: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita no campo da tela de recuperação de senha o código incorreto
        
        # language: pt
        Given que o cliente esteja na tela de recuperação de senha
        And digita incorretamente o código de recuperação de senha
        When ao tentar avançar para o campo de senha
        Then o cliente recebe uma mensagem na tela informando que o código de recuperação de senha está incorreto