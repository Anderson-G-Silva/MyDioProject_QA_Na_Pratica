Feature: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa caracteres numéricos ou caracteres especiais no campo nome no cartão
    @TestCaseKey=SLS-T28
    Scenario Outline: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa caracteres numéricos ou caracteres especiais no campo nome no cartão
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de meios de pagamento
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de meios de pagamento
        And digita no campo número do cartão 5031 4332 1540 6351
        And digita no campo nome no cartão Maria de Sousa9$ 
        When tenta passar para o próximo campo
        Then o cliente recebe uma mensagem na tela informando que no campo destacado em vermelho não aceita caracteres numéricos ou caracteres especiais
        Examples: | ação | | botão novo meio de pagamento | | link alterar de um meio de pagamento cadastrado |