Feature: Cliente tem cadastro mas esqueceu a senha e tenta recuperá-la
    @TestCaseKey=SLS-T4
    Scenario: Cliente tem cadastro mas esqueceu a senha e tenta recuperá-la
        
        # language: pt
        
        Given que o cliente esteja na tela de login na URL https://www.saucedemo.com/
        And  digita no campo username Maria_Souza
        But não lembra da senha
        When clica no link de recuperar senha
        Then o cliente é direcionado para a tela de recuperação de senha