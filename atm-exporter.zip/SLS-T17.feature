Feature: Cliente tem cadastro na rede social, mas não está conectado a ela no momento e tenta fazer login com a senha correta 
    @TestCaseKey=SLS-T17
    Scenario: Cliente tem cadastro na rede social, mas não está conectado a ela no momento e tenta fazer login com a senha correta 
        
        # Language: pt
        Given que o cliente esteja na tela de interface de login da rede social
        And tenha cadastro no sistema da rede social
        And não está conectado a conta da rede social no momento
        And digita no campo usuário o e-mail mariasouza@gmail.com
        And digita no campo senha senhacorreta
        When clicar no botão login
        Then o cliente é direcionado para a homepage da plataforma de compras