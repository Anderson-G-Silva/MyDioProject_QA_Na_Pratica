Feature: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa um número do cartão inválido
    @TestCaseKey=SLS-T27
    Scenario Outline: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa um número do cartão inválido
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de meios de pagamento
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de meios de pagamento
        And digita no campo número do cartão 4242 4242 4242 4241
        When tenta passar para o próximo campo
        Then o cliente recebe uma mensagem na tela informando que o número do cartão é inválido
        Examples: | ação | | botão novo meio de pagamento | | link alterar de um meio de pagamento cadastrado |