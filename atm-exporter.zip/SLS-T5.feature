Feature: Cliente tem cadastro e tenta fazer login com a senha correta
    @TestCaseKey=SLS-T5
    Scenario: Cliente tem cadastro e tenta fazer login com a senha correta
        
        # language: pt
        Given que o cliente esteja na tela de login na URL https://www.saucedemo.com/
        And digita no campo username Maria_Souza
        And no campo password digita a senha Ma@Sa$1599
        When clica no botão login
        Then o cliente  é direcionado para a homepage da plataforma de compras