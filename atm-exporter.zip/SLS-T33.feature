Feature: Cliente preenche dados para criação de nova conta, mas a idade é inferior a 18 anos
    @TestCaseKey=SLS-T33
    Scenario: Cliente preenche dados para criação de nova conta, mas a idade é inferior a 18 anos
        
        # language: pt
        Given que o cliente esteja na tela de criação de nova conta
        And digita no campo username Maria_Souza
        And digita no campo nome completo Maria de Souza
        And digita no campo data de nascimento 01/01/2010
        And digita no campo CPF 12345678909
        And digita no campo E-mail mariasouza@gmail.com
        And digita no campo password Ma@Sa$1599
        But digita no campo confirmar password Ma@Sa$1599
        When clicar no botão criar conta
        Then o cliente recebe uma mensagem na tela informando que a idade é inferior a 18 anos e que não será possível realizar o cadastro
        And retorna para a tela inicial de login.