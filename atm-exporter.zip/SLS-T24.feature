Feature: Cliente clica no link excluir é direcionado para a tela de exclusão de endereço, mas cancela o processo.
    @TestCaseKey=SLS-T24
    Scenario: Cliente clica no link excluir é direcionado para a tela de exclusão de endereço, mas cancela o processo.
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de endereços
        And clica no link excluir do endereço Casa
        And é direcionado para a tela de exclusão de endereços
        When clicar no botão cancelar exclusão
        Then o cliente recebe uma mensagem na tela informando que a exclusão não foi concluída
        And retorna a tela inicial de endereços