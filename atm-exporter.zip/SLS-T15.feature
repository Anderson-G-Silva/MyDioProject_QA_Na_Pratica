Feature: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita nova senha corretamente
    @TestCaseKey=SLS-T15
    Scenario: Cliente ativo recebe código de recuperação de senha enviado no e-mail cadastrado e digita nova senha corretamente
        
        # language: pt
        Given que o cliente esteja na tela de recuperação de senha
        And digita o e-mail cadastrado mariasouza@gmail.com
        And recebe e-mail com código para recuperação de senha 123456
        And digita na tela de recuperação de senha o codigo 123456
        And digita no campo password Ma@Sa$1527
        And digita no campo confirmar password Ma@Sa$1527
        When clicar no botão salvar senha
        Then o cliente recebe uma mensagem na tela informando que a nova senha foi salva com sucesso