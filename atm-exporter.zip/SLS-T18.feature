Feature: Cliente tem cadastro na rede social e está conectado a ela no momento 
    @TestCaseKey=SLS-T18
    Scenario: Cliente tem cadastro na rede social e está conectado a ela no momento 
        
        # Language: pt
        Given que o cliente esteja na tela de interface de login da rede social
        And tenha cadastro no sistema da rede social
        And está conectado a conta da rede social no momento
        When clicar no botão continuar como Maria de Souza
        Then o cliente é direcionado para a homepage da plataforma de compras