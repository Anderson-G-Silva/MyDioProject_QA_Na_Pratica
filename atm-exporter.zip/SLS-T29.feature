Feature: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa caracteres alfabéticos ou caracteres especiais no campo CVV
    @TestCaseKey=SLS-T29
    Scenario Outline: Cliente clica no botão novo meio de pagamento ou no link alterar, é direcionado para a tela de preenchimento de dados para criação de novo meio de pagamento ou alteração e informa caracteres alfabéticos ou caracteres especiais no campo CVV
        
        # language: pt
        Given que o cliente esteja na tela de cadastro de meios de pagamento
        And seleciona opção de ação “<ação>”
        And é direcionado para a tela de alteração ou criação de meios de pagamento
        And digita no campo número do cartão 5031 4332 1540 6351
        And digita no campo nome no cartão Maria de Souza 
        And digita no campo CVV 1A$
        When tenta passar para o próximo campo
        Then o cliente recebe uma mensagem na tela informando que no campo destacado em vermelho só são permitidos números de 0 a 9
        Examples: | ação | | botão novo meio de pagamento | | link alterar de um meio de pagamento cadastrado |